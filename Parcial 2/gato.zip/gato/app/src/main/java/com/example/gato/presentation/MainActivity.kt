package com.example.gato.presentation

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.foundation.lazy.ScalingLazyColumn
import androidx.wear.compose.foundation.lazy.rememberScalingLazyListState
import androidx.wear.compose.material.Button
import androidx.wear.compose.material.ButtonDefaults
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.Text

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                TicTacToeGameScreen()
            }
        }
    }
}

@SuppressLint("UnusedBoxWithConstraintsScope")
@Composable
fun TicTacToeGameScreen() {
    val listState = rememberScalingLazyListState()
    
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black) 
    ) {
        val minSide = minOf(maxWidth, maxHeight)
        val cellSize = minSide / 5 

        ScalingLazyColumn(
            modifier = Modifier.fillMaxSize(),
            state = listState,
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            item {
                TicTacToeGame(cellSize = cellSize)
            }
        }
    }
}

@Composable
fun TicTacToeGame(cellSize: Dp) {
    var board by remember { mutableStateOf(List(3)
    { MutableList(3) { "" } }) }
    var currentPlayer by remember { mutableStateOf("X") }
    var winner by remember { mutableStateOf<String?>(null) }

    val resetGame = {
        board = List(3) { MutableList(3) { "" } }
        currentPlayer = "X"
        winner = null
    }

    val fontSizeStatus = cellSize.value * 0.35
    val fontSizeCell = cellSize.value * 0.6
    val buttonFontSize = cellSize.value * 0.32

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .padding(cellSize * 0.1f)
            .fillMaxWidth()
    ) {
        
        if (winner != null) {
            Text("Ganador: $winner", color = Color.Green, fontSize = fontSizeStatus.sp)
        } else if (board.flatten().none { it.isEmpty() }) {
            Text("¡Empate!", color = Color.Yellow, fontSize = fontSizeStatus.sp)
        } else {
            Text("Turno: $currentPlayer", color = Color.White, fontSize = fontSizeStatus.sp)
        }

        Spacer(modifier = Modifier.height(cellSize * 0.2f))

        
        for (i in 0..2) {
            Row(horizontalArrangement = Arrangement.Center) {
                for (j in 0..2) {
                    BoardCell(
                        value = board[i][j],
                        onClick = {
                            if (board[i][j] == "" && winner == null) {
                                val newBoard = board.map { it.toMutableList() }.toMutableList()
                                newBoard[i][j] = currentPlayer
                                board = newBoard
                                winner = checkWinner(board)
                                if (winner == null) {
                                    currentPlayer = if (currentPlayer == "X") "O" else "X"
                                }
                            }
                        },
                        size = cellSize,
                        fontSize = fontSizeCell.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(cellSize * 0.2f))

        Button(
            onClick = resetGame,
            colors = ButtonDefaults.buttonColors(backgroundColor = Color.Yellow),
            modifier = Modifier
                .fillMaxWidth(0.45f) 
                .height(cellSize * 0.6f) 
        ) {
            Text("Reiniciar", fontSize = buttonFontSize.sp, color = Color.Black)
        }
    }
}

@Composable
fun BoardCell(value: String, onClick: () -> Unit, size: Dp, fontSize: TextUnit) {
    
    val textColor = when (value) {
        "X" -> Color.Red
        "O" -> Color.Green
        else -> Color.Transparent
    }
    Box(
        modifier = Modifier
            .size(size)
            .padding(1.dp)
            .border(
                BorderStroke(1.dp, Color.White),
                shape = RoundedCornerShape(size * 0.25f) 
            )
            .background(Color.Transparent, shape = RoundedCornerShape
                (size * 0.25f))
            .clickable(onClick = onClick, enabled = value.isEmpty()),
        contentAlignment = Alignment.Center
    ) {
        Text(text = value, color = textColor, fontSize = fontSize)
    }
}

fun checkWinner(board: List<List<String>>): String? {
    
    for (i in 0..2) {
        if (board[i][0].isNotEmpty() && board[i][0] == board[i][1] && board[i][1]
            == board[i][2])
            return board[i][0]
        if (board[0][i].isNotEmpty() && board[0][i] == board[1][i] && board[1][i]
            == board[2][i])
            return board[0][i]
    }
    
    if (board[0][0].isNotEmpty() && board[0][0] == board[1][1] && board[1][1]
        == board[2][2])
        return board[0][0]
    if (board[0][2].isNotEmpty() && board[0][2] == board[1][1] && board[1][1]
        == board[2][0])
        return board[0][2]
    return null
}