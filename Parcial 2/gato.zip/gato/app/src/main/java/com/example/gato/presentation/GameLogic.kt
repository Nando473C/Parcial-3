package com.example.gato.presentation

class GameLogic {
    var board = Array(3) { Array(3) { "" } }

    fun makeMove(row: Int, col: Int, player: String): Boolean {
        if (board[row][col].isEmpty()) {
            board[row][col] = player
            return true
        }
        return false
    }

    fun checkWinner(): String {
        for (i in 0..2) {
            if (board[i][0] == board[i][1] && board[i][1] == board[i][2] && board[i][0] != "")
                return board[i][0]
            if (board[0][i] == board[1][i] && board[1][i] == board[2][i] && board[0][i] != "")
                return board[0][i]
        }
        if (board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[0][0] != "")
            return board[0][0]
        if (board[0][2] == board[1][1] && board[1][1] == board[2][0] && board[0][2] != "")
            return board[0][2]

        return ""
    }

    fun resetBoard() {
        board = Array(3) { Array(3) { "" } }
    }
}
