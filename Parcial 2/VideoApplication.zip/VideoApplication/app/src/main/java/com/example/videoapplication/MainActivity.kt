package com.example.videoapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.videoapplication.data.Video
import com.example.videoapplication.data.VideoRepository
import com.example.videoapplication.screens.HomeScreen
import com.example.videoapplication.screens.SplashScreen
import com.example.videoapplication.screens.VideoPlayerScreen
import com.example.videoapplication.ui.theme.VideoApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VideoApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    VideoApp()
                }
            }
        }
    }
}

@Composable
fun VideoApp() {
    val navController = rememberNavController()
    
    NavHost(
        navController = navController,
        startDestination = "splash"
    ) {
        composable("splash") {
            SplashScreen(
                onSplashFinished = {
                    navController.navigate("home") {
                        popUpTo("splash") { inclusive = true }
                    }
                }
            )
        }
        
        composable("home") {
            HomeScreen(
                onVideoClick = { video ->
                    navController.navigate("player/${video.id}")
                }
            )
        }
        
        composable("player/{videoId}") { backStackEntry ->
            val videoId = backStackEntry.arguments?.getString("videoId")
            val video = VideoRepository.sampleVideos.find { it.id == videoId }
            
            video?.let {
                VideoPlayerScreen(
                    video = it,
                    onBackClick = {
                        navController.popBackStack()
                    }
                )
            }
        }
    }
}