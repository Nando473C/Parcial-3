package com.example.videoapplication.ui.theme

import androidx.compose.ui.graphics.Color

// Colores modernos para video app
val Purple80 = Color(0xFFBB86FC)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Colores específicos para la app
val VideoRed = Color(0xFFFF0000)
val VideoRedDark = Color(0xFFCC0000)
val BackgroundDark = Color(0xFF121212)
val SurfaceDark = Color(0xFF1E1E1E)
val CardBackground = Color(0xFF2D2D2D)