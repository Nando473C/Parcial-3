//
//  WatchGoalSettingsView.swift
//  Bloom Well Watch Watch App
//
//  Created by Karina Banda on 21/07/25.
//

import SwiftUI

struct WatchGoalSettingsView: View {
    @EnvironmentObject var waterTracker: WaterTracker
    
    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 10) {
                Text("⚙️ Meta")
                    .font(.headline)
                    .foregroundColor(.black)
                
                // Meta actual
                VStack(spacing: 4) {
                    Text("Vasos diarios")
                        .font(.caption)
                        .foregroundColor(.black)
                    
                    Text("\(waterTracker.dailyGoal)")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                }
                
                // Botones para ajustar
                HStack(spacing: 15) {
                    Button(action: {
                        if waterTracker.dailyGoal > 1 {
                            waterTracker.dailyGoal -= 1
                        }
                    }) {
                        Image(systemName: "minus.circle")
                            .font(.title2)
                            .foregroundColor(.red)
                    }
                    .disabled(waterTracker.dailyGoal <= 1)
                    .buttonStyle(PlainButtonStyle())
                    
                    Button(action: {
                        if waterTracker.dailyGoal < 20 {
                            waterTracker.dailyGoal += 1
                        }
                    }) {
                        Image(systemName: "plus.circle")
                            .font(.title2)
                            .foregroundColor(.green)
                    }
                    .disabled(waterTracker.dailyGoal >= 20)
                    .buttonStyle(PlainButtonStyle())
                }
                
                // Total en ML
                Text("\(waterTracker.dailyGoal * waterTracker.glassSize) ml")
                    .font(.caption2)
                    .foregroundColor(.black)
                
                // Reset button
                Button("Reset día") {
                    waterTracker.resetDaily()
                }
                .font(.caption)
                .foregroundColor(.red)
                .buttonStyle(PlainButtonStyle())
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
            .background(Color(red: 0.996, green: 0.957, blue: 0.831))
        }
        .ignoresSafeArea()
    }
}

#Preview {
    WatchGoalSettingsView()
        .environmentObject(WaterTracker())
}