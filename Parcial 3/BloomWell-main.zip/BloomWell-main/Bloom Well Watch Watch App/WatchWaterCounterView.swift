//
//  WatchWaterCounterView.swift
//  Bloom Well Watch Watch App
//
//  Created by Karina Banda on 21/07/25.
//

import SwiftUI

struct WatchWaterCounterView: View {
    @EnvironmentObject var waterTracker: WaterTracker
    
    var currentPhase: Int {
        switch waterTracker.progressPercentage {
        case 0.0:
            return 0
        case 0.0...0.33:
            return 1
        case 0.34...0.66:
            return 2
        default:
            return 3
        }
    }
    
    var backgroundColor: Color {
        switch currentPhase {
        case 0:
            return Color(red: 1.0, green: 0.937, blue: 0.769) // #ffefc4
        case 2:
            return Color(red: 1.0, green: 0.941, blue: 0.749) // #fff0bf
        default:
            return Color(red: 0.996, green: 0.957, blue: 0.831) // #fef4d4
        }
    }
    
    var body: some View {
        VStack(spacing: 6) {
            Spacer(minLength: 10)
            
            // Imagen principal más grande
            WatchProgressPhaseView(progress: waterTracker.progressPercentage, size: 140)
            
            // Info en una línea: vasos actuales/meta + ml
            Text("\(waterTracker.currentIntake)/\(waterTracker.dailyGoal) vasos - \(waterTracker.totalMl)ml")
                .font(.caption2)
                .foregroundColor(.black)
                .fontWeight(.medium)
            
            // Solo botón de sumar
            Button(action: {
                waterTracker.addGlass()
            }) {
                Image(systemName: "plus.circle.fill")
                    .font(.title)
                    .foregroundColor(.blue)
            }
            .buttonStyle(PlainButtonStyle())
            
            Spacer(minLength: 10)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(backgroundColor)
    }
}

#Preview {
    WatchWaterCounterView()
        .environmentObject(WaterTracker())
}