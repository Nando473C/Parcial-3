//
//  WatchProgressPhaseView.swift
//  Bloom Well Watch Watch App
//
//  Created by Karina Banda on 21/07/25.
//

import SwiftUI

struct WatchProgressPhaseView: View {
    let progress: Double
    let size: CGFloat
    
    var currentPhase: Int {
        switch progress {
        case 0.0:
            return 0
        case 0.0...0.33:
            return 1
        case 0.34...0.66:
            return 2
        default:
            return 3
        }
    }
    
    var phaseImage: String {
        switch currentPhase {
        case 0:
            return "Etapa0"
        case 1:
            return "Etapa1"
        case 2:
            return "Etapa2"
        default:
            return "Etapa3"
        }
    }
    
    var phaseColor: Color {
        switch currentPhase {
        case 0:
            return .gray
        case 1:
            return .orange
        case 2:
            return .blue
        default:
            return .green
        }
    }
    
    var body: some View {
        // Solo la imagen de la fase
        Image(phaseImage)
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: size, height: size)
            .scaleEffect(progress > 0 ? 1.0 : 0.8)
            .animation(.spring(response: 0.4, dampingFraction: 0.8), value: currentPhase)
    }
}

#Preview {
    VStack(spacing: 20) {
        WatchProgressPhaseView(progress: 0.2, size: 60)
        WatchProgressPhaseView(progress: 0.5, size: 60)
        WatchProgressPhaseView(progress: 0.9, size: 60)
    }
}