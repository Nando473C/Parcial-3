//
//  WaterTracker.swift
//  Bloom Well Watch Watch App
//
//  Created by Karina Banda on 21/07/25.
//

import Foundation
import Combine

class WaterTracker: ObservableObject {
    @Published var currentIntake: Int = 0
    @Published var dailyGoal: Int = 8
    @Published var glassSize: Int = 250 // ml
    
    private let userDefaults = UserDefaults(suiteName: "group.apps.bloom-well") ?? UserDefaults.standard
    
    init() {
        loadData()
        setupSyncNotifications()
    }
    
    private func setupSyncNotifications() {
        NotificationCenter.default.addObserver(
            forName: UserDefaults.didChangeNotification,
            object: userDefaults,
            queue: .main
        ) { _ in
            self.loadData()
        }
    }
    
    func addGlass() {
        currentIntake += 1
        saveData()
    }
    
    func removeGlass() {
        if currentIntake > 0 {
            currentIntake -= 1
            saveData()
        }
    }
    
    func resetDaily() {
        currentIntake = 0
        saveData()
    }
    
    var progressPercentage: Double {
        guard dailyGoal > 0 else { return 0 }
        return min(1.0, Double(currentIntake) / Double(dailyGoal))
    }
    
    var totalMl: Int {
        return currentIntake * glassSize
    }
    
    private func saveData() {
        userDefaults.set(currentIntake, forKey: "currentIntake")
        userDefaults.set(dailyGoal, forKey: "dailyGoal")
        userDefaults.set(glassSize, forKey: "glassSize")
        userDefaults.synchronize()
    }
    
    private func loadData() {
        currentIntake = userDefaults.integer(forKey: "currentIntake")
        dailyGoal = userDefaults.integer(forKey: "dailyGoal")
        glassSize = userDefaults.integer(forKey: "glassSize")
        
        // Valores por defecto si es primera vez
        if dailyGoal == 0 { dailyGoal = 8 }
        if glassSize == 0 { glassSize = 250 }
    }
}