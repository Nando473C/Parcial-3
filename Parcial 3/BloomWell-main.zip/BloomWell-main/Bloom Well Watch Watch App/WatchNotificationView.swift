//
//  WatchNotificationView.swift
//  Bloom Well Watch Watch App
//
//  Created by Karina Banda on 21/07/25.
//

import SwiftUI
import UserNotifications

struct WatchNotificationView: View {
    @State private var notificationsEnabled = false
    @State private var reminderInterval = 60
    
    var body: some View {
        ScrollView {
            VStack(spacing: 10) {
            Text("🔔 Avisos")
                .font(.headline)
                .foregroundColor(.black)
            
            // Toggle principal
            Toggle("Recordatorios", isOn: $notificationsEnabled)
                .font(.caption)
                .foregroundColor(.black)
                .onChange(of: notificationsEnabled) { oldValue, newValue in
                    if newValue {
                        requestNotificationPermission()
                    } else {
                        cancelNotifications()
                    }
                }
            
            if notificationsEnabled {
                // Selector de intervalo
                VStack(spacing: 4) {
                    Text("Cada: \(reminderInterval == 30 ? "30m" : reminderInterval == 60 ? "1h" : "2h")")
                        .font(.caption2)
                        .foregroundColor(.black)
                    
                    HStack(spacing: 8) {
                        Button("30m") {
                            reminderInterval = 30
                            if notificationsEnabled { scheduleNotifications() }
                        }
                        .font(.caption2)
                        .foregroundColor(reminderInterval == 30 ? .black : .gray)
                        .fontWeight(reminderInterval == 30 ? .bold : .regular)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 3)
                        .background(reminderInterval == 30 ? Color(red: 0.9, green: 0.8, blue: 0.6) : Color(red: 0.95, green: 0.9, blue: 0.8))
                        .cornerRadius(4)
                        
                        Button("1h") {
                            reminderInterval = 60
                            if notificationsEnabled { scheduleNotifications() }
                        }
                        .font(.caption2)
                        .foregroundColor(reminderInterval == 60 ? .black : .gray)
                        .fontWeight(reminderInterval == 60 ? .bold : .regular)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 3)
                        .background(reminderInterval == 60 ? Color(red: 0.9, green: 0.8, blue: 0.6) : Color(red: 0.95, green: 0.9, blue: 0.8))
                        .cornerRadius(4)
                        
                        Button("2h") {
                            reminderInterval = 120
                            if notificationsEnabled { scheduleNotifications() }
                        }
                        .font(.caption2)
                        .foregroundColor(reminderInterval == 120 ? .black : .gray)
                        .fontWeight(reminderInterval == 120 ? .bold : .regular)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 3)
                        .background(reminderInterval == 120 ? Color(red: 0.9, green: 0.8, blue: 0.6) : Color(red: 0.95, green: 0.9, blue: 0.8))
                        .cornerRadius(4)
                    }
                }
            }
            
            // Botón de prueba
            Button("Probar") {
                sendTestNotification()
            }
            .font(.caption2)
            .foregroundColor(.black)
            .fontWeight(.medium)
            .padding(.horizontal, 10)
            .padding(.vertical, 4)
            .background(Color(red: 0.9, green: 0.8, blue: 0.6))
            .cornerRadius(6)
            
            // Estado
            if notificationsEnabled {
                Text("✅ Activo")
                    .font(.caption2)
                    .foregroundColor(.green)
            } else {
                VStack(spacing: 2) {
                    Text("⏸️ Pausado")
                        .font(.caption2)
                        .foregroundColor(.red)
                    Text("Configuración > Notificaciones")
                        .font(.caption2)
                        .foregroundColor(.gray)
                }
            }
                
                Spacer(minLength: 10)
            }
            .padding(.horizontal, 8)
        }
        .background(Color(red: 0.996, green: 0.957, blue: 0.831))
        .onAppear {
            loadNotificationSettings()
        }
    }
    
    private func requestNotificationPermission() {
        print("Requesting notification permission...")
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            print("Permission result: granted=\(granted), error=\(String(describing: error))")
            DispatchQueue.main.async {
                self.notificationsEnabled = granted
                if granted {
                    self.scheduleNotifications()
                } else {
                    print("Permission denied, toggle will be off")
                }
            }
        }
    }
    
    private func scheduleNotifications() {
        cancelNotifications()
        
        let content = UNMutableNotificationContent()
        content.title = "💧 Bloom Well"
        content.body = "¡Hora de beber agua!"
        content.sound = .default
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: TimeInterval(reminderInterval * 60), repeats: true)
        let request = UNNotificationRequest(identifier: "watchWaterReminder", content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request)
    }
    
    private func cancelNotifications() {
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
    }
    
    private func sendTestNotification() {
        print("Sending test notification...")
        
        let content = UNMutableNotificationContent()
        content.title = "💧 Bloom Well"
        content.body = "¡Prueba desde Watch!"
        content.sound = .default
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("Error: \(error.localizedDescription)")
            } else {
                print("Test notification scheduled!")
            }
        }
    }
    
    private func loadNotificationSettings() {
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            DispatchQueue.main.async {
                print("Raw status: \(settings.authorizationStatus.rawValue)")
                print("Status enum: \(settings.authorizationStatus)")
                print("Authorized constant: \(UNAuthorizationStatus.authorized.rawValue)")
                
                let isAuthorized = settings.authorizationStatus == .authorized
                self.notificationsEnabled = isAuthorized
                print("Is authorized: \(isAuthorized)")
                print("Toggle set to: \(self.notificationsEnabled)")
            }
        }
    }
}

#Preview {
    WatchNotificationView()
}