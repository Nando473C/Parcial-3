//
//  Bloom_WellTests.swift
//  Bloom WellTests
//
//  Created by Karina Banda on 21/07/25.
//

import Testing

struct Bloom_WellTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
